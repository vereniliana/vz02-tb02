/** 
  * @author NIM/Nama: 13515144 / William
  * Nama file : Sex.java
  */

package src.animal;

public enum Sex {
  MALE, FEMALE
}
